//
//  ViewController.swift
//  LoadJSONinCoreData
//
//  Created by Naveen Gundu on 25/12/16.
//  Copyright © 2016 NaveenG. All rights reserved.
//

import UIKit
import Foundation


class ViewController: UIViewController {

    var filePath = NSString()
    var ItemType_Name = NSArray()
    var Item_Code = NSArray()
    var Item_Description = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//         filePath = "Stock_File-1"
//        var fileSize : UInt64
//        var attr:NSDictionary? = FileManager.defaultManager.attributesOfItemAtPath(filePath, error: nil)
        
//        var path = Bundle.main.url(forResource: "Stock_File-1", withExtension: "txt")!
//        var dic = try! JSONSerialization.jsonObject(with: NSData(contentsOf: path) as Data, options: JSONSerialization.ReadingOptions(rawValue: 1))
//        print("DIc=\(dic)")
//        var aar = ((dic as AnyObject).value("ItemType_Name") as! String)
        
        var path = Bundle.main.url(forResource: "Stock_File-1", withExtension: "txt")!
        var dic = try! JSONSerialization.jsonObject(with: NSData(contentsOf: path) as Data, options: JSONSerialization.ReadingOptions(rawValue: 1))
        print("DIc=\(dic)")
        
        let ItemType_Name = (dic as AnyObject).value(forKey: "ItemType_Name") as! NSArray
        let Item_Code = (dic as AnyObject).value(forKey: "Item_Code") as! NSArray
        let Item_Description = (dic as AnyObject).value(forKey: "Item_Description") as! NSArray

        
        print(ItemType_Name)
        print(Item_Code)
        print(Item_Description)
        
        

//        var aar = ((dic as AnyObject).value("ItemType_Name") as! String)

        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

